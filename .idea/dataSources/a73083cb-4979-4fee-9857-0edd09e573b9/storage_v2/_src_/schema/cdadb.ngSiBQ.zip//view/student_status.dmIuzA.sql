create definer = root@localhost view student_status as
select json_array(group_concat(distinct `s`.`student_id` separator ','),
                  group_concat(distinct `s`.`student_name` separator ','),
                  group_concat(distinct `s`.`student_gender` separator ','),
                  group_concat(distinct `s`.`student_birth` separator ','),
                  group_concat(distinct `s`.`student_major` separator ','))                                AS `student_data`,
       json_array(group_concat(`c`.`course_no` separator ','), group_concat(`c`.`course_name` separator ','),
                  group_concat(`g`.`CreditHours` separator ','),
                  group_concat(`g`.`Credit` separator ','))                                                AS `class_data`
from (((`cdadb`.`student` `s` left join `cdadb`.`major` `m`
        on ((`s`.`student_major` = `m`.`major_name`))) left join `cdadb`.`course` `c`
       on ((`c`.`course_no` member of (`m`.`major_courselist`) = true))) left join `cdadb`.`grade` `g`
      on (((`g`.`grade_student_no` = `s`.`student_id`) and (`g`.`CourseNo` = `c`.`course_no`))))
group by `s`.`student_id`;

